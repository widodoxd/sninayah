import type { ReactNode } from "react";

export function PageHero({
  eyebrow,
  title,
  desc,
}: {
  eyebrow: string;
  title: string;
  desc: string;
}) {
  return (
    <header className="border-b border-border bg-gradient-hero">
      <div className="mx-auto max-w-6xl px-4 py-12 md:py-16">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">{eyebrow}</p>
        <h1 className="mt-3 font-display text-3xl font-bold leading-tight text-primary-foreground md:text-4xl">
          {title}
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-primary-foreground/80 md:text-base">
          {desc}
        </p>
      </div>
    </header>
  );
}

export function Section({
  title,
  children,
  lead,
}: {
  title?: string;
  lead?: string;
  children: ReactNode;
}) {
  return (
    <section className="mx-auto max-w-6xl px-4 py-10">
      {title && (
        <h2 className="font-display text-xl font-bold text-foreground md:text-2xl">{title}</h2>
      )}
      {lead && <p className="mt-2 max-w-3xl text-sm text-muted-foreground">{lead}</p>}
      <div className={title || lead ? "mt-6" : ""}>{children}</div>
    </section>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-xl border border-border bg-card p-5 shadow-soft transition-shadow hover:shadow-elegant ${className}`}
    >
      {children}
    </div>
  );
}

export function InfoList({ rows }: { rows: [string, string][] }) {
  return (
    <dl className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
      {rows.map(([k, v]) => (
        <div key={k} className="grid gap-1 px-5 py-3 sm:grid-cols-3">
          <dt className="text-sm font-medium text-muted-foreground">{k}</dt>
          <dd className="text-sm text-foreground sm:col-span-2">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Badge({ children, tone = "default" }: { children: ReactNode; tone?: "default" | "accent" | "muted" }) {
  const tones = {
    default: "bg-primary/10 text-primary",
    accent: "bg-accent/20 text-accent-foreground",
    muted: "bg-muted text-muted-foreground",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function Table({ head, rows }: { head: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card">
      <table className="w-full text-sm">
        <thead className="bg-secondary text-secondary-foreground">
          <tr>
            {head.map((h) => (
              <th key={h} className="px-4 py-3 text-left font-semibold whitespace-nowrap">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {rows.map((r, i) => (
            <tr key={i} className="hover:bg-muted/50">
              {r.map((c, j) => (
                <td key={j} className="px-4 py-3 text-foreground">
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
