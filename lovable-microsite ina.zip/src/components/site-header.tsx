import { Link } from "@tanstack/react-router";
import { Menu, X, BookMarked, ChevronDown } from "lucide-react";
import { useState } from "react";

import { menus, grupMenu, sekolah } from "@/lib/site-data";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link to="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="grid size-10 place-items-center rounded-lg bg-gradient-brand text-primary-foreground">
            <BookMarked className="size-5" />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-sm font-bold text-foreground">Microsite Guru PAI</span>
            <span className="block text-xs text-muted-foreground">{sekolah.nama}</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          <Link
            to="/"
            className="rounded-md px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
            activeOptions={{ exact: true }}
            activeProps={{ className: "bg-muted" }}
          >
            Beranda
          </Link>
          {grupMenu.map((g) => (
            <div key={g} className="relative" onMouseLeave={() => setOpenGroup(null)}>
              <button
                type="button"
                onMouseEnter={() => setOpenGroup(g)}
                onClick={() => setOpenGroup(openGroup === g ? null : g)}
                className="flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
              >
                {g}
                <ChevronDown className="size-4" />
              </button>
              {openGroup === g && (
                <div className="absolute left-0 top-full w-72 rounded-xl border border-border bg-popover p-2 shadow-elegant">
                  {menus
                    .filter((m) => m.group === g)
                    .map((m) => (
                      <Link
                        key={m.to}
                        to={m.to}
                        onClick={() => setOpenGroup(null)}
                        className="block rounded-lg px-3 py-2 text-sm text-popover-foreground hover:bg-muted"
                        activeProps={{ className: "bg-muted font-semibold" }}
                      >
                        {m.label}
                      </Link>
                    ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        <button
          type="button"
          aria-label="Buka menu"
          onClick={() => setOpen(!open)}
          className="grid size-10 place-items-center rounded-lg border border-border text-foreground lg:hidden"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open && (
        <div className="max-h-[70vh] overflow-y-auto border-t border-border bg-background lg:hidden">
          <div className="mx-auto max-w-6xl px-4 py-3">
            <Link
              to="/"
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-muted"
            >
              Beranda
            </Link>
            {grupMenu.map((g) => (
              <div key={g} className="mt-3">
                <p className="px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{g}</p>
                {menus
                  .filter((m) => m.group === g)
                  .map((m) => (
                    <Link
                      key={m.to}
                      to={m.to}
                      onClick={() => setOpen(false)}
                      className="block rounded-lg px-3 py-2 text-sm text-foreground hover:bg-muted"
                      activeProps={{ className: "bg-muted font-semibold" }}
                    >
                      {m.label}
                    </Link>
                  ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
