import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";

import { menus, sekolah, guru } from "@/lib/site-data";

export function SiteFooter() {
  return (
    <footer className="mt-16 bg-gradient-brand text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 md:grid-cols-3">
        <div>
          <h2 className="font-display text-lg font-bold">{sekolah.nama}</h2>
          <p className="mt-2 text-sm text-primary-foreground/80">
            Microsite guru {guru.mapel} sebagai wadah dokumentasi administrasi, pembelajaran, dan
            pembiasaan keagamaan.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-primary-foreground/80">
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 size-4 shrink-0" /> {sekolah.alamat}
            </li>
            <li className="flex items-center gap-2">
              <Phone className="size-4 shrink-0" /> {sekolah.telepon}
            </li>
            <li className="flex items-center gap-2">
              <Mail className="size-4 shrink-0" /> {sekolah.email}
            </li>
          </ul>
        </div>
        <div className="md:col-span-2">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-accent">Daftar Menu</h3>
          <ul className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
            {menus.map((m) => (
              <li key={m.to}>
                <Link to={m.to} className="text-primary-foreground/80 hover:text-primary-foreground">
                  {m.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-primary-foreground/15 py-4 text-center text-xs text-primary-foreground/70">
        &copy; {new Date().getFullYear()} {guru.nama} — {sekolah.nama}
      </div>
    </footer>
  );
}
