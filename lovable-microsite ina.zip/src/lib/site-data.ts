export const sekolah = {
  nama: "SD Negeri Nganti 1",
  npsn: "20314567",
  alamat: "Desa Nganti, Kec. Wonosegoro, Kab. Boyolali, Jawa Tengah",
  email: "sdnnganti1@gmail.com",
  telepon: "(0298) 000-0000",
  akreditasi: "B",
  kepsek: "Sri Handayani, S.Pd.",
};

export const guru = {
  nama: "Ahmad Fauzi, S.Pd.I.",
  mapel: "Pendidikan Agama Islam dan Budi Pekerti",
  nip: "19880212 201203 1 004",
  pangkat: "Penata Muda Tk. I / III-b",
  email: "fauzi.pai@gmail.com",
};

export type MenuItem = { to: string; label: string; desc: string; group: string };

export const menus: MenuItem[] = [
  { to: "/profil-sekolah", label: "Profil Sekolah", desc: "Identitas, sejarah, dan data pokok sekolah", group: "Profil" },
  { to: "/visi-misi", label: "Visi Misi", desc: "Visi, misi, dan tujuan sekolah", group: "Profil" },
  { to: "/curriculum-vitae", label: "Curriculum Vitae", desc: "Biodata, pendidikan, dan riwayat mengajar guru", group: "Profil" },
  { to: "/pengembangan-diri", label: "Pengembangan Diri", desc: "Diklat, seminar, KKG, dan komunitas belajar", group: "Profil" },
  { to: "/program-ajar", label: "Program Ajar", desc: "CP, TP, ATP, dan modul ajar per fase", group: "Pembelajaran" },
  { to: "/kegiatan-kbm", label: "Kegiatan KBM", desc: "Dokumentasi kegiatan belajar mengajar", group: "Pembelajaran" },
  { to: "/asesmen-pembelajaran", label: "Asesmen Pembelajaran", desc: "Asesmen diagnostik, formatif, dan sumatif", group: "Pembelajaran" },
  { to: "/piloting-pai-berkarakter", label: "Piloting Sekolah PAI Berkarakter", desc: "Program piloting dan capaiannya", group: "Pembelajaran" },
  { to: "/analisa-hasil-asesmen", label: "Analisa Hasil Asesmen", desc: "Rekap nilai dan analisis ketercapaian", group: "Data" },
  { to: "/data-siswa", label: "Data Siswa", desc: "Rekap siswa per kelas", group: "Data" },
  { to: "/bank-soal", label: "Bank Soal", desc: "Kumpulan soal PAI per kelas dan materi", group: "Data" },
  { to: "/pembiasaan-keagamaan", label: "Pembiasaan Keagamaan", desc: "Sholat dhuha, tahfidz, jumat berkah", group: "Kegiatan" },
  { to: "/galeri", label: "Galeri", desc: "Foto kegiatan pembelajaran dan keagamaan", group: "Kegiatan" },
  { to: "/berkas-tpg", label: "Berkas TPG", desc: "Dokumen tunjangan profesi guru", group: "Kegiatan" },
];

export const grupMenu = ["Profil", "Pembelajaran", "Data", "Kegiatan"] as const;

export const dataSiswa = [
  { kelas: "I", lakiLaki: 12, perempuan: 10, muslim: 20, waliKelas: "Endang Sulistyowati, S.Pd." },
  { kelas: "II", lakiLaki: 11, perempuan: 13, muslim: 22, waliKelas: "Ratna Puspita, S.Pd." },
  { kelas: "III", lakiLaki: 14, perempuan: 9, muslim: 21, waliKelas: "Bambang Riyadi, S.Pd." },
  { kelas: "IV", lakiLaki: 10, perempuan: 15, muslim: 23, waliKelas: "Siti Aminah, S.Pd." },
  { kelas: "V", lakiLaki: 13, perempuan: 12, muslim: 24, waliKelas: "Yusuf Maulana, S.Pd." },
  { kelas: "VI", lakiLaki: 15, perempuan: 11, muslim: 25, waliKelas: "Dwi Lestari, S.Pd." },
];

export const bankSoal = [
  { kelas: "I", materi: "Huruf Hijaiyah", bentuk: "Pilihan Ganda", jumlah: 20, level: "Mudah" },
  { kelas: "II", materi: "Asmaul Husna", bentuk: "Isian Singkat", jumlah: 15, level: "Mudah" },
  { kelas: "III", materi: "Sholat Wajib", bentuk: "Pilihan Ganda", jumlah: 25, level: "Sedang" },
  { kelas: "IV", materi: "Kisah Nabi Ulul Azmi", bentuk: "Uraian", jumlah: 10, level: "Sedang" },
  { kelas: "IV", materi: "Q.S. Al-Hujurat: 13", bentuk: "Pilihan Ganda", jumlah: 20, level: "Sedang" },
  { kelas: "V", materi: "Zakat dan Infak", bentuk: "Pilihan Ganda", jumlah: 25, level: "Sedang" },
  { kelas: "VI", materi: "Iman kepada Qada dan Qadar", bentuk: "Uraian", jumlah: 10, level: "Sulit" },
  { kelas: "VI", materi: "Puasa Ramadhan", bentuk: "Benar-Salah", jumlah: 20, level: "Sedang" },
];

export const hasilAsesmen = [
  { kelas: "I", rata: 82, tuntas: 90 },
  { kelas: "II", rata: 79, tuntas: 86 },
  { kelas: "III", rata: 84, tuntas: 92 },
  { kelas: "IV", rata: 77, tuntas: 80 },
  { kelas: "V", rata: 86, tuntas: 94 },
  { kelas: "VI", rata: 88, tuntas: 96 },
];

export const berkasTpg = [
  { nama: "SK Pembagian Tugas Mengajar", tahun: "2025/2026", status: "Lengkap" },
  { nama: "Jadwal Mengajar Tersahkan", tahun: "2025/2026", status: "Lengkap" },
  { nama: "Daftar Hadir Bulanan", tahun: "Semester 1", status: "Proses" },
  { nama: "Sertifikat Pendidik", tahun: "2019", status: "Lengkap" },
  { nama: "SKMT dan SKBK", tahun: "2025/2026", status: "Lengkap" },
  { nama: "Fotokopi Rekening & NPWP", tahun: "-", status: "Lengkap" },
  { nama: "Laporan Kinerja Guru (e-Kinerja)", tahun: "2025", status: "Proses" },
];
