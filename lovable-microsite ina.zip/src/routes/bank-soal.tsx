import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";

import { Badge, PageHero, Section, Table } from "@/components/page-shell";
import { bankSoal } from "@/lib/site-data";

export const Route = createFileRoute("/bank-soal")({
  head: () => ({
    meta: [
      { title: "Bank Soal PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Kumpulan soal Pendidikan Agama Islam per kelas dan materi, lengkap dengan bentuk soal dan tingkat kesulitan." },
      { property: "og:title", content: "Bank Soal PAI" },
      { property: "og:description", content: "Kumpulan soal PAI per kelas dan materi." },
    ],
  }),
  component: Page,
});

const kelasList = ["Semua", "I", "II", "III", "IV", "V", "VI"];

function Page() {
  const [kelas, setKelas] = useState("Semua");
  const rows = useMemo(
    () => (kelas === "Semua" ? bankSoal : bankSoal.filter((b) => b.kelas === kelas)),
    [kelas],
  );

  return (
    <>
      <PageHero
        eyebrow="Menu 11"
        title="Bank Soal"
        desc="Kumpulan butir soal PAI yang tervalidasi dan siap digunakan untuk asesmen formatif maupun sumatif."
      />
      <Section title="Daftar Paket Soal">
        <div className="mb-4 flex flex-wrap gap-2">
          {kelasList.map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setKelas(k)}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                kelas === k
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-foreground hover:bg-muted"
              }`}
            >
              {k === "Semua" ? "Semua Kelas" : `Kelas ${k}`}
            </button>
          ))}
        </div>
        <Table
          head={["Kelas", "Materi", "Bentuk Soal", "Jumlah Butir", "Level"]}
          rows={rows.map((b) => [
            `Kelas ${b.kelas}`,
            b.materi,
            b.bentuk,
            b.jumlah,
            <Badge key={b.materi} tone={b.level === "Sulit" ? "accent" : "muted"}>
              {b.level}
            </Badge>,
          ])}
        />
      </Section>
      <Section title="Kaidah Penyusunan Soal">
        <ul className="list-inside list-disc space-y-2 rounded-xl border border-border bg-card p-5 text-sm text-muted-foreground">
          <li>Setiap butir soal mengacu pada tujuan pembelajaran yang telah ditetapkan.</li>
          <li>Bahasa sederhana, sesuai tingkat perkembangan siswa sekolah dasar.</li>
          <li>Komposisi level kognitif: 40% mudah, 40% sedang, 20% sulit.</li>
          <li>Disertai kunci jawaban dan pedoman penskoran untuk soal uraian.</li>
        </ul>
      </Section>
    </>
  );
}
