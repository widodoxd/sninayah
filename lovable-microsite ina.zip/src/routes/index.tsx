import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BookOpen, HeartHandshake, Star } from "lucide-react";

import { menus, sekolah, guru, grupMenu } from "@/lib/site-data";
import { Card, Section } from "@/components/page-shell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Microsite Guru PAI — SD Negeri Nganti 1" },
      {
        name: "description",
        content:
          "Beranda microsite guru PAI SD Negeri Nganti 1: 14 menu berisi profil, program ajar, asesmen, data siswa, bank soal, galeri, dan berkas TPG.",
      },
      { property: "og:title", content: "Microsite Guru PAI — SD Negeri Nganti 1" },
      {
        property: "og:description",
        content: "Dokumentasi lengkap pembelajaran PAI dan Budi Pekerti SD Negeri Nganti 1.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="bg-gradient-hero">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-[1.2fr_1fr] md:py-24">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-accent">
              Microsite Guru PAI
            </p>
            <h1 className="mt-4 font-display text-4xl font-bold leading-tight text-primary-foreground md:text-5xl">
              {sekolah.nama}
            </h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-primary-foreground/85 md:text-base">
              Ruang dokumentasi digital pembelajaran {guru.mapel}. Berisi administrasi guru, program
              ajar, asesmen, pembiasaan keagamaan, hingga berkas tunjangan profesi dalam satu tempat.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/profil-sekolah"
                className="inline-flex items-center gap-2 rounded-lg bg-accent px-5 py-2.5 text-sm font-semibold text-accent-foreground transition-opacity hover:opacity-90"
              >
                Profil Sekolah <ArrowRight className="size-4" />
              </Link>
              <Link
                to="/program-ajar"
                className="inline-flex items-center gap-2 rounded-lg border border-primary-foreground/30 px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-foreground/10"
              >
                Program Ajar
              </Link>
            </div>
          </div>
          <div className="rounded-2xl border border-primary-foreground/20 bg-primary-foreground/10 p-6 backdrop-blur">
            <h2 className="font-display text-lg font-bold text-primary-foreground">Guru Pengampu</h2>
            <dl className="mt-4 space-y-3 text-sm">
              {[
                ["Nama", guru.nama],
                ["NIP", guru.nip],
                ["Mata Pelajaran", guru.mapel],
                ["Pangkat/Golongan", guru.pangkat],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="text-primary-foreground/70">{k}</dt>
                  <dd className="font-medium text-primary-foreground">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <Section title="14 Menu Microsite" lead="Seluruh dokumentasi tertata dalam empat kelompok utama.">
        <div className="space-y-8">
          {grupMenu.map((g) => (
            <div key={g}>
              <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                {g}
              </h3>
              <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {menus
                  .filter((m) => m.group === g)
                  .map((m) => (
                    <Link key={m.to} to={m.to} className="block">
                      <Card>
                        <div className="flex items-start justify-between gap-3">
                          <h4 className="font-display text-base font-bold text-foreground">{m.label}</h4>
                          <ArrowRight className="mt-1 size-4 shrink-0 text-accent" />
                        </div>
                        <p className="mt-2 text-sm text-muted-foreground">{m.desc}</p>
                      </Card>
                    </Link>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Fokus Pembelajaran PAI">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { icon: BookOpen, t: "Literasi Al-Qur'an", d: "Pembiasaan membaca dan menghafal surat pendek setiap awal pembelajaran." },
            { icon: HeartHandshake, t: "Akhlak Mulia", d: "Penguatan sikap jujur, disiplin, hormat kepada guru dan orang tua." },
            { icon: Star, t: "Ibadah Praktis", d: "Praktik wudhu, sholat, dan adab harian yang terukur melalui jurnal siswa." },
          ].map((f) => (
            <Card key={f.t}>
              <span className="grid size-10 place-items-center rounded-lg bg-secondary text-secondary-foreground">
                <f.icon className="size-5" />
              </span>
              <h3 className="mt-4 font-display text-base font-bold text-foreground">{f.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
            </Card>
          ))}
        </div>
      </Section>
    </>
  );
}
