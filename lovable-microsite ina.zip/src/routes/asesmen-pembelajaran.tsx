import { createFileRoute } from "@tanstack/react-router";

import { Badge, Card, PageHero, Section, Table } from "@/components/page-shell";

export const Route = createFileRoute("/asesmen-pembelajaran")({
  head: () => ({
    meta: [
      { title: "Asesmen Pembelajaran PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Jenis asesmen PAI: diagnostik, formatif, dan sumatif beserta instrumen dan rubriknya." },
      { property: "og:title", content: "Asesmen Pembelajaran PAI" },
      { property: "og:description", content: "Asesmen diagnostik, formatif, dan sumatif mata pelajaran PAI." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 6"
        title="Asesmen Pembelajaran"
        desc="Perencanaan dan instrumen penilaian PAI yang mengukur pengetahuan, keterampilan ibadah, dan sikap."
      />
      <Section title="Jenis Asesmen">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ["Diagnostik", "Awal tahun", "Mengukur kemampuan awal baca Al-Qur'an dan hafalan surat pendek."],
            ["Formatif", "Setiap pertemuan", "Observasi, kuis singkat, praktik, dan penugasan harian."],
            ["Sumatif", "Akhir lingkup materi", "Tes tertulis, praktik ibadah, dan proyek keagamaan."],
          ].map(([t, w, d]) => (
            <Card key={t}>
              <Badge tone="accent">{w}</Badge>
              <h3 className="mt-3 font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Instrumen dan Teknik">
        <Table
          head={["Aspek", "Teknik", "Instrumen", "Bobot"]}
          rows={[
            ["Pengetahuan", "Tes tertulis", "Soal pilihan ganda & uraian", "40%"],
            ["Keterampilan", "Praktik", "Rubrik praktik wudhu & sholat", "35%"],
            ["Sikap", "Observasi", "Jurnal sikap harian", "15%"],
            ["Hafalan", "Setoran hafalan", "Kartu tahfidz", "10%"],
          ]}
        />
      </Section>
      <Section title="Rubrik Praktik Ibadah">
        <Table
          head={["Nilai", "Kriteria"]}
          rows={[
            ["4 — Sangat Baik", "Gerakan dan bacaan benar, tertib, tanpa bantuan"],
            ["3 — Baik", "Gerakan benar, bacaan sedikit keliru"],
            ["2 — Cukup", "Perlu bimbingan pada beberapa bagian"],
            ["1 — Perlu Bimbingan", "Belum mampu melakukan secara mandiri"],
          ]}
        />
      </Section>
    </>
  );
}
