import { createFileRoute } from "@tanstack/react-router";
import { X } from "lucide-react";
import { useState } from "react";

import { PageHero, Section } from "@/components/page-shell";
import sholat from "@/assets/galeri-sholat.jpg";
import kbm from "@/assets/galeri-kbm.jpg";
import tahfidz from "@/assets/galeri-tahfidz.jpg";
import infak from "@/assets/galeri-infak.jpg";

export const Route = createFileRoute("/galeri")({
  head: () => ({
    meta: [
      { title: "Galeri Kegiatan — Guru PAI SD Negeri Nganti 1" },
      { name: "description", content: "Foto kegiatan pembelajaran PAI dan pembiasaan keagamaan siswa SD Negeri Nganti 1." },
      { property: "og:title", content: "Galeri Kegiatan PAI" },
      { property: "og:description", content: "Dokumentasi foto kegiatan pembelajaran dan keagamaan." },
    ],
  }),
  component: Page,
});

const foto = [
  { src: sholat, alt: "Siswa melaksanakan sholat berjamaah di mushola sekolah", judul: "Sholat Dhuha Berjamaah" },
  { src: kbm, alt: "Guru PAI membimbing siswa membaca Al-Qur'an di kelas", judul: "Bimbingan Baca Al-Qur'an" },
  { src: tahfidz, alt: "Kegiatan setoran hafalan dan kajian keputrian siswa", judul: "Setoran Hafalan & Keputrian" },
  { src: infak, alt: "Siswa memasukkan infak ke kotak amal pada hari Jumat", judul: "Jumat Berkah" },
];

function Page() {
  const [aktif, setAktif] = useState<number | null>(null);

  return (
    <>
      <PageHero
        eyebrow="Menu 13"
        title="Galeri"
        desc="Dokumentasi visual kegiatan pembelajaran PAI dan pembiasaan keagamaan di lingkungan sekolah."
      />
      <Section title="Foto Kegiatan">
        <div className="grid gap-4 sm:grid-cols-2">
          {foto.map((f, i) => (
            <button
              key={f.judul}
              type="button"
              onClick={() => setAktif(i)}
              className="group overflow-hidden rounded-xl border border-border bg-card text-left shadow-soft"
            >
              <img
                src={f.src}
                alt={f.alt}
                loading="lazy"
                width={1280}
                height={853}
                className="aspect-[3/2] w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <span className="block px-4 py-3 font-display text-base font-bold text-foreground">
                {f.judul}
              </span>
            </button>
          ))}
        </div>
      </Section>

      {aktif !== null && foto[aktif] && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 grid place-items-center bg-foreground/80 p-4"
          onClick={() => setAktif(null)}
        >
          <div className="relative max-w-3xl" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              aria-label="Tutup"
              onClick={() => setAktif(null)}
              className="absolute -top-12 right-0 grid size-10 place-items-center rounded-full bg-card text-foreground"
            >
              <X className="size-5" />
            </button>
            <img
              src={foto[aktif]!.src}
              alt={foto[aktif]!.alt}
              width={1280}
              height={853}
              className="w-full rounded-xl"
            />
            <p className="mt-3 text-center text-sm text-background">{foto[aktif]!.judul}</p>
          </div>
        </div>
      )}
    </>
  );
}
