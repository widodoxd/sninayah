import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";

import { Card, PageHero, Section, Table } from "@/components/page-shell";
import { dataSiswa } from "@/lib/site-data";

export const Route = createFileRoute("/data-siswa")({
  head: () => ({
    meta: [
      { title: "Data Siswa — SD Negeri Nganti 1" },
      { name: "description", content: "Rekap jumlah siswa per kelas SD Negeri Nganti 1 beserta wali kelas dan jumlah siswa muslim." },
      { property: "og:title", content: "Data Siswa SD Negeri Nganti 1" },
      { property: "og:description", content: "Rekap siswa per kelas dan wali kelasnya." },
    ],
  }),
  component: Page,
});

function Page() {
  const [q, setQ] = useState("");
  const rows = useMemo(
    () =>
      dataSiswa.filter(
        (d) =>
          d.kelas.toLowerCase().includes(q.toLowerCase()) ||
          d.waliKelas.toLowerCase().includes(q.toLowerCase()),
      ),
    [q],
  );
  const total = dataSiswa.reduce((a, b) => a + b.lakiLaki + b.perempuan, 0);
  const muslim = dataSiswa.reduce((a, b) => a + b.muslim, 0);

  return (
    <>
      <PageHero
        eyebrow="Menu 10"
        title="Data Siswa"
        desc="Rekapitulasi peserta didik tahun pelajaran 2025/2026 sebagai dasar perencanaan pembelajaran PAI."
      />
      <Section>
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            ["Total Siswa", total],
            ["Siswa Muslim", muslim],
            ["Jumlah Kelas", dataSiswa.length],
          ].map(([t, v]) => (
            <Card key={String(t)}>
              <p className="text-sm text-muted-foreground">{t}</p>
              <p className="mt-2 font-display text-3xl font-bold text-primary">{v}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Rekap per Kelas">
        <label className="mb-4 flex max-w-sm items-center gap-2 rounded-lg border border-input bg-card px-3 py-2">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari kelas atau wali kelas"
            className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
          />
        </label>
        <Table
          head={["Kelas", "Laki-laki", "Perempuan", "Jumlah", "Muslim", "Wali Kelas"]}
          rows={rows.map((d) => [
            `Kelas ${d.kelas}`,
            d.lakiLaki,
            d.perempuan,
            d.lakiLaki + d.perempuan,
            d.muslim,
            d.waliKelas,
          ])}
        />
        {rows.length === 0 && (
          <p className="mt-4 text-sm text-muted-foreground">Data tidak ditemukan.</p>
        )}
      </Section>
    </>
  );
}
