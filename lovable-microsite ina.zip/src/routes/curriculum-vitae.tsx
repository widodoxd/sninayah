import { createFileRoute } from "@tanstack/react-router";

import { Card, InfoList, PageHero, Section, Table } from "@/components/page-shell";
import { guru, sekolah } from "@/lib/site-data";

export const Route = createFileRoute("/curriculum-vitae")({
  head: () => ({
    meta: [
      { title: "Curriculum Vitae Guru PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Biodata, riwayat pendidikan, pengalaman mengajar, dan sertifikasi guru PAI SD Negeri Nganti 1." },
      { property: "og:title", content: "Curriculum Vitae Guru PAI" },
      { property: "og:description", content: "Biodata dan riwayat profesional guru PAI SD Negeri Nganti 1." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 3"
        title="Curriculum Vitae"
        desc="Rekam jejak profesional guru Pendidikan Agama Islam dan Budi Pekerti."
      />
      <Section title="Biodata">
        <InfoList
          rows={[
            ["Nama Lengkap", guru.nama],
            ["NIP", guru.nip],
            ["Pangkat/Golongan", guru.pangkat],
            ["Mata Pelajaran", guru.mapel],
            ["Unit Kerja", sekolah.nama],
            ["Email", guru.email],
          ]}
        />
      </Section>
      <Section title="Riwayat Pendidikan">
        <Table
          head={["Jenjang", "Institusi", "Jurusan", "Tahun Lulus"]}
          rows={[
            ["SD", "SD Negeri Nganti 2", "-", "2000"],
            ["SMP", "SMP Negeri 1 Wonosegoro", "-", "2003"],
            ["MA", "MA Al-Islam Boyolali", "Keagamaan", "2006"],
            ["S1", "IAIN Surakarta", "Pendidikan Agama Islam", "2011"],
          ]}
        />
      </Section>
      <Section title="Pengalaman Mengajar">
        <Table
          head={["Periode", "Satuan Pendidikan", "Tugas"]}
          rows={[
            ["2011 - 2012", "MI Muhammadiyah Nganti", "Guru PAI"],
            ["2012 - sekarang", sekolah.nama, "Guru PAI kelas I-VI"],
            ["2022 - sekarang", "KKG PAI Kecamatan", "Anggota pengurus"],
          ]}
        />
      </Section>
      <Section title="Sertifikasi & Penghargaan">
        <div className="grid gap-4 md:grid-cols-2">
          {[
            ["Sertifikat Pendidik PAI", "Nomor 1234567/2019 — LPTK UIN Walisongo"],
            ["Instruktur Pembelajaran PAI", "Tingkat kabupaten, 2023"],
            ["Guru Berprestasi", "Juara 2 tingkat kecamatan, 2024"],
            ["Sertifikat Piloting PAI Berkarakter", "Kemenag, 2025"],
          ].map(([t, d]) => (
            <Card key={t}>
              <h3 className="font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
    </>
  );
}
