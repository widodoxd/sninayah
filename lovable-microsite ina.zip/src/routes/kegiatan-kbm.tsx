import { createFileRoute } from "@tanstack/react-router";

import { Badge, Card, PageHero, Section, Table } from "@/components/page-shell";

export const Route = createFileRoute("/kegiatan-kbm")({
  head: () => ({
    meta: [
      { title: "Kegiatan KBM PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Dokumentasi kegiatan belajar mengajar PAI: metode, media, dan jadwal per kelas." },
      { property: "og:title", content: "Kegiatan KBM PAI" },
      { property: "og:description", content: "Dokumentasi kegiatan belajar mengajar PAI SD Negeri Nganti 1." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 5"
        title="Kegiatan KBM"
        desc="Catatan pelaksanaan pembelajaran PAI di kelas: metode yang digunakan, media, dan refleksi guru."
      />
      <Section title="Jadwal Mengajar">
        <Table
          head={["Hari", "Kelas", "Jam", "Materi Pokok"]}
          rows={[
            ["Senin", "VI", "07.30 - 09.00", "Iman kepada qada dan qadar"],
            ["Senin", "V", "09.30 - 11.00", "Zakat dan infak"],
            ["Selasa", "IV", "07.30 - 09.00", "Toleransi dalam Islam"],
            ["Selasa", "III", "09.30 - 11.00", "Praktik sholat"],
            ["Rabu", "II", "07.30 - 08.40", "Asmaul husna"],
            ["Rabu", "I", "09.00 - 10.10", "Huruf hijaiyah"],
          ]}
        />
      </Section>
      <Section title="Metode & Media Pembelajaran">
        <div className="grid gap-4 md:grid-cols-2">
          {[
            ["Praktik Langsung", "Siswa mempraktikkan wudhu dan sholat di mushola secara berkelompok."],
            ["Tutor Sebaya", "Siswa yang lancar membaca membimbing teman dalam kelompok kecil."],
            ["Bercerita Kisah Nabi", "Penguatan akhlak melalui kisah dan tanya jawab reflektif."],
            ["Media Audio Visual", "Tayangan video tata cara ibadah melalui proyektor kelas."],
          ].map(([t, d]) => (
            <Card key={t}>
              <Badge>Metode</Badge>
              <h3 className="mt-3 font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Refleksi Guru">
        <Card>
          <ul className="list-inside list-disc space-y-2 text-sm text-muted-foreground">
            <li>Antusiasme siswa meningkat saat pembelajaran dilakukan dengan praktik langsung.</li>
            <li>Perlu penambahan waktu bimbingan baca Al-Qur'an untuk siswa kelas rendah.</li>
            <li>Penilaian sikap lebih efektif menggunakan jurnal harian per kelas.</li>
          </ul>
        </Card>
      </Section>
    </>
  );
}
