import { createFileRoute } from "@tanstack/react-router";
import { FileText } from "lucide-react";

import { Badge, Card, PageHero, Section, Table } from "@/components/page-shell";

export const Route = createFileRoute("/program-ajar")({
  head: () => ({
    meta: [
      { title: "Program Ajar PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Capaian pembelajaran, tujuan pembelajaran, alur tujuan pembelajaran, dan modul ajar PAI per fase." },
      { property: "og:title", content: "Program Ajar PAI" },
      { property: "og:description", content: "CP, TP, ATP, dan modul ajar PAI SD Negeri Nganti 1." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 4"
        title="Program Ajar"
        desc="Perangkat pembelajaran PAI dan Budi Pekerti berbasis Kurikulum Merdeka untuk fase A, B, dan C."
      />
      <Section title="Perangkat per Fase">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ["Fase A — Kelas I & II", "Huruf hijaiyah, asmaul husna, adab kepada orang tua"],
            ["Fase B — Kelas III & IV", "Sholat wajib, kisah nabi, Q.S. pilihan, zakat dasar"],
            ["Fase C — Kelas V & VI", "Puasa, iman kepada qada dan qadar, sejarah kebudayaan Islam"],
          ].map(([t, d]) => (
            <Card key={t}>
              <Badge tone="accent">Kurikulum Merdeka</Badge>
              <h3 className="mt-3 font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Alur Tujuan Pembelajaran (ATP)" lead="Ringkasan alur satu semester untuk setiap tingkat kelas.">
        <Table
          head={["Kelas", "Elemen", "Tujuan Pembelajaran", "Alokasi"]}
          rows={[
            ["I", "Al-Qur'an Hadis", "Melafalkan huruf hijaiyah berharakat fathah", "8 JP"],
            ["II", "Akidah", "Menyebutkan makna asmaul husna Ar-Rahman dan Ar-Rahim", "6 JP"],
            ["III", "Fikih", "Mempraktikkan gerakan dan bacaan sholat wajib", "10 JP"],
            ["IV", "Akhlak", "Menerapkan sikap toleransi sesuai Q.S. Al-Hujurat: 13", "8 JP"],
            ["V", "Fikih", "Menjelaskan ketentuan zakat fitrah dan infak", "8 JP"],
            ["VI", "Akidah", "Menunjukkan perilaku beriman kepada qada dan qadar", "10 JP"],
          ]}
        />
      </Section>
      <Section title="Dokumen Modul Ajar">
        <div className="grid gap-3 sm:grid-cols-2">
          {["Modul Ajar Fase A", "Modul Ajar Fase B", "Modul Ajar Fase C", "Program Tahunan & Semester", "Analisis CP-TP", "Kalender Pendidikan"].map((d) => (
            <div key={d} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <span className="flex items-center gap-3 text-sm text-foreground">
                <FileText className="size-4 text-accent" /> {d}
              </span>
              <Badge tone="muted">PDF</Badge>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}
