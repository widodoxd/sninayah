import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { Card, PageHero, Section, Table } from "@/components/page-shell";
import { hasilAsesmen } from "@/lib/site-data";

export const Route = createFileRoute("/analisa-hasil-asesmen")({
  head: () => ({
    meta: [
      { title: "Analisa Hasil Asesmen PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Rekap nilai rata-rata dan persentase ketuntasan asesmen PAI setiap kelas beserta tindak lanjutnya." },
      { property: "og:title", content: "Analisa Hasil Asesmen PAI" },
      { property: "og:description", content: "Rekap nilai dan analisis ketercapaian asesmen PAI per kelas." },
    ],
  }),
  component: Page,
});

function Page() {
  const rata = Math.round(hasilAsesmen.reduce((a, b) => a + b.rata, 0) / hasilAsesmen.length);
  const tuntas = Math.round(hasilAsesmen.reduce((a, b) => a + b.tuntas, 0) / hasilAsesmen.length);

  return (
    <>
      <PageHero
        eyebrow="Menu 8"
        title="Analisa Hasil Asesmen"
        desc="Ringkasan capaian asesmen sumatif PAI semester berjalan sebagai dasar perbaikan pembelajaran."
      />
      <Section>
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            ["Rata-rata Nilai", `${rata}`],
            ["Ketuntasan", `${tuntas}%`],
            ["Kelas Dianalisis", `${hasilAsesmen.length}`],
          ].map(([t, v]) => (
            <Card key={t}>
              <p className="text-sm text-muted-foreground">{t}</p>
              <p className="mt-2 font-display text-3xl font-bold text-primary">{v}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Grafik Capaian per Kelas">
        <Card>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hasilAsesmen}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="kelas" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis domain={[0, 100]} stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: 12,
                    color: "var(--foreground)",
                  }}
                />
                <Bar dataKey="rata" name="Rata-rata" fill="var(--chart-1)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="tuntas" name="Ketuntasan (%)" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </Section>
      <Section title="Rekap dan Tindak Lanjut">
        <Table
          head={["Kelas", "Rata-rata", "Ketuntasan", "Tindak Lanjut"]}
          rows={hasilAsesmen.map((h) => [
            `Kelas ${h.kelas}`,
            h.rata,
            `${h.tuntas}%`,
            h.tuntas >= 90 ? "Pengayaan materi" : "Remedial dan bimbingan kelompok kecil",
          ])}
        />
      </Section>
    </>
  );
}
