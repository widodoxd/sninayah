import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";

import { Card, PageHero, Section } from "@/components/page-shell";

export const Route = createFileRoute("/visi-misi")({
  head: () => ({
    meta: [
      { title: "Visi Misi — SD Negeri Nganti 1" },
      { name: "description", content: "Visi, misi, dan tujuan SD Negeri Nganti 1 dalam membentuk siswa beriman dan berprestasi." },
      { property: "og:title", content: "Visi Misi — SD Negeri Nganti 1" },
      { property: "og:description", content: "Visi, misi, dan tujuan SD Negeri Nganti 1." },
    ],
  }),
  component: Page,
});

const misi = [
  "Menyelenggarakan pembelajaran aktif, kreatif, dan menyenangkan.",
  "Menanamkan pembiasaan ibadah dan akhlak mulia dalam kehidupan sehari-hari.",
  "Mengembangkan potensi siswa melalui kegiatan ekstrakurikuler yang terarah.",
  "Membangun budaya literasi dan numerasi di seluruh tingkat kelas.",
  "Menjalin kemitraan dengan orang tua dan masyarakat dalam pendidikan karakter.",
  "Menciptakan lingkungan sekolah yang bersih, aman, dan ramah anak.",
];

const tujuan = [
  "Siswa mampu membaca Al-Qur'an sesuai tingkat kelasnya.",
  "Siswa terbiasa melaksanakan sholat dan adab harian dengan benar.",
  "Capaian asesmen PAI berada di atas ketuntasan minimal sekolah.",
  "Terwujudnya profil pelajar Pancasila yang beriman dan berakhlak mulia.",
];

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 2"
        title="Visi dan Misi"
        desc="Arah pengembangan sekolah yang menjadi rujukan penyusunan program pembelajaran PAI."
      />
      <Section title="Visi">
        <Card>
          <p className="font-display text-xl leading-relaxed text-foreground md:text-2xl">
            &ldquo;Terwujudnya peserta didik yang beriman, bertakwa, berakhlak mulia, cerdas, dan
            berbudaya lingkungan.&rdquo;
          </p>
        </Card>
      </Section>
      <Section title="Misi">
        <ul className="grid gap-3 md:grid-cols-2">
          {misi.map((m) => (
            <li key={m} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
              <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-secondary text-secondary-foreground">
                <Check className="size-4" />
              </span>
              <span className="text-sm text-foreground">{m}</span>
            </li>
          ))}
        </ul>
      </Section>
      <Section title="Tujuan Pembelajaran PAI">
        <ol className="space-y-3">
          {tujuan.map((t, i) => (
            <li key={t} className="flex gap-3 rounded-xl border border-border bg-card p-4">
              <span className="font-display text-lg font-bold text-accent">{i + 1}</span>
              <span className="text-sm text-foreground">{t}</span>
            </li>
          ))}
        </ol>
      </Section>
    </>
  );
}
