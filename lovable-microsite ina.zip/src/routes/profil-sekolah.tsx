import { createFileRoute } from "@tanstack/react-router";

import { InfoList, PageHero, Section, Card } from "@/components/page-shell";
import { sekolah } from "@/lib/site-data";

export const Route = createFileRoute("/profil-sekolah")({
  head: () => ({
    meta: [
      { title: "Profil Sekolah — SD Negeri Nganti 1" },
      { name: "description", content: "Identitas, sejarah singkat, dan data pokok SD Negeri Nganti 1." },
      { property: "og:title", content: "Profil Sekolah — SD Negeri Nganti 1" },
      { property: "og:description", content: "Identitas, sejarah singkat, dan data pokok SD Negeri Nganti 1." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 1"
        title="Profil Sekolah"
        desc="Identitas lembaga, sejarah singkat, serta data pokok penyelenggaraan pendidikan di SD Negeri Nganti 1."
      />
      <Section title="Identitas Sekolah">
        <InfoList
          rows={[
            ["Nama Sekolah", sekolah.nama],
            ["NPSN", sekolah.npsn],
            ["Jenjang", "Sekolah Dasar (SD)"],
            ["Status", "Negeri"],
            ["Akreditasi", sekolah.akreditasi],
            ["Kepala Sekolah", sekolah.kepsek],
            ["Alamat", sekolah.alamat],
            ["Telepon", sekolah.telepon],
            ["Email", sekolah.email],
            ["Kurikulum", "Kurikulum Merdeka"],
          ]}
        />
      </Section>
      <Section title="Sejarah Singkat">
        <Card>
          <p className="text-sm leading-relaxed text-muted-foreground">
            SD Negeri Nganti 1 berdiri sebagai sekolah dasar negeri yang melayani masyarakat Desa
            Nganti dan sekitarnya. Sejak awal berdirinya, sekolah berkomitmen menghadirkan layanan
            pendidikan dasar yang bermutu, menanamkan karakter religius, serta membangun kerja sama
            erat dengan orang tua dan tokoh masyarakat setempat.
          </p>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Pembelajaran Pendidikan Agama Islam dan Budi Pekerti menjadi salah satu penguat karakter
            utama, ditopang program pembiasaan keagamaan harian dan kegiatan keagamaan tahunan.
          </p>
        </Card>
      </Section>
      <Section title="Sarana Pendukung PAI">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Mushola Sekolah", "Tempat praktik sholat dan pembiasaan dhuha"],
            ["Pojok Baca Islami", "Buku iqra, juz amma, dan kisah nabi"],
            ["Alat Peraga Ibadah", "Peraga wudhu, sholat, dan manasik"],
            ["Proyektor Kelas", "Media tayang video pembelajaran PAI"],
          ].map(([t, d]) => (
            <Card key={t}>
              <h3 className="font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
    </>
  );
}
