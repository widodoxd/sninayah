import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";

import { Badge, Card, PageHero, Section, Table } from "@/components/page-shell";

export const Route = createFileRoute("/piloting-pai-berkarakter")({
  head: () => ({
    meta: [
      { title: "Piloting Sekolah PAI Berkarakter — SD Negeri Nganti 1" },
      { name: "description", content: "Latar belakang, program aksi, dan capaian piloting Sekolah PAI Berkarakter di SD Negeri Nganti 1." },
      { property: "og:title", content: "Piloting Sekolah PAI Berkarakter" },
      { property: "og:description", content: "Program dan capaian piloting Sekolah PAI Berkarakter." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 7"
        title="Piloting Sekolah PAI Berkarakter"
        desc="Program penguatan karakter religius melalui pembelajaran PAI yang kontekstual, moderat, dan berbasis pembiasaan."
      />
      <Section title="Latar Belakang">
        <Card>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Piloting Sekolah PAI Berkarakter merupakan program penguatan pendidikan agama yang
            menempatkan nilai religius sebagai ruh seluruh kegiatan sekolah. SD Negeri Nganti 1
            ditunjuk sebagai sekolah pelaksana dengan fokus pada tiga hal: pembelajaran PAI yang
            bermakna, pembiasaan ibadah harian, dan pelibatan orang tua.
          </p>
        </Card>
      </Section>
      <Section title="Lima Nilai Karakter Utama">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {["Religius", "Jujur", "Disiplin", "Peduli", "Tanggung Jawab", "Moderat"].map((n) => (
            <div key={n} className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
              <span className="grid size-8 place-items-center rounded-full bg-secondary text-secondary-foreground">
                <Check className="size-4" />
              </span>
              <span className="font-display text-base font-bold text-foreground">{n}</span>
            </div>
          ))}
        </div>
      </Section>
      <Section title="Program Aksi & Capaian">
        <Table
          head={["Program", "Sasaran", "Indikator", "Status"]}
          rows={[
            ["Gerakan Sholat Dhuha", "Kelas III-VI", "80% siswa rutin dhuha", <Badge key="1" tone="accent">Tercapai</Badge>],
            ["Satu Hari Satu Ayat", "Kelas I-VI", "Setoran hafalan mingguan", <Badge key="2" tone="accent">Tercapai</Badge>],
            ["Jumat Berbagi", "Seluruh siswa", "Infak rutin tiap Jumat", <Badge key="3" tone="accent">Tercapai</Badge>],
            ["Parenting Keagamaan", "Orang tua", "2 kali per semester", <Badge key="4" tone="muted">Proses</Badge>],
            ["Kelas Tahfidz Pilihan", "Kelas IV-VI", "30 siswa hafal 10 surat", <Badge key="5" tone="muted">Proses</Badge>],
          ]}
        />
      </Section>
    </>
  );
}
