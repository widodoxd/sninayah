import { createFileRoute } from "@tanstack/react-router";
import { Download, FileText } from "lucide-react";

import { Badge, Card, PageHero, Section } from "@/components/page-shell";
import { berkasTpg } from "@/lib/site-data";

export const Route = createFileRoute("/berkas-tpg")({
  head: () => ({
    meta: [
      { title: "Berkas TPG — Guru PAI SD Negeri Nganti 1" },
      { name: "description", content: "Daftar kelengkapan berkas Tunjangan Profesi Guru (TPG) guru PAI SD Negeri Nganti 1." },
      { property: "og:title", content: "Berkas TPG Guru PAI" },
      { property: "og:description", content: "Kelengkapan dokumen tunjangan profesi guru beserta statusnya." },
    ],
  }),
  component: Page,
});

function Page() {
  const lengkap = berkasTpg.filter((b) => b.status === "Lengkap").length;

  return (
    <>
      <PageHero
        eyebrow="Menu 14"
        title="Berkas TPG"
        desc="Administrasi Tunjangan Profesi Guru: daftar dokumen, periode, dan status kelengkapannya."
      />
      <Section>
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            ["Total Berkas", `${berkasTpg.length}`],
            ["Sudah Lengkap", `${lengkap}`],
            ["Dalam Proses", `${berkasTpg.length - lengkap}`],
          ].map(([t, v]) => (
            <Card key={t}>
              <p className="text-sm text-muted-foreground">{t}</p>
              <p className="mt-2 font-display text-3xl font-bold text-primary">{v}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Daftar Dokumen" lead="Unduhan akan aktif setelah dokumen asli diunggah ke microsite.">
        <div className="space-y-3">
          {berkasTpg.map((b) => (
            <div
              key={b.nama}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-4"
            >
              <div className="flex items-start gap-3">
                <FileText className="mt-0.5 size-5 text-accent" />
                <div>
                  <p className="text-sm font-medium text-foreground">{b.nama}</p>
                  <p className="text-xs text-muted-foreground">Periode: {b.tahun}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge tone={b.status === "Lengkap" ? "accent" : "muted"}>{b.status}</Badge>
                <button
                  type="button"
                  disabled={b.status !== "Lengkap"}
                  className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-muted disabled:opacity-40"
                >
                  <Download className="size-4" /> Unduh
                </button>
              </div>
            </div>
          ))}
        </div>
      </Section>
      <Section title="Alur Pengajuan">
        <ol className="space-y-3">
          {[
            "Melengkapi berkas administrasi dan legalisasi dokumen di sekolah.",
            "Pengesahan SKMT dan SKBK oleh kepala sekolah dan pengawas.",
            "Verifikasi data pada Simpatika/Dapodik dan pembaruan e-Kinerja.",
            "Pengajuan ke Kementerian Agama kabupaten untuk pencairan.",
          ].map((s, i) => (
            <li key={s} className="flex gap-3 rounded-xl border border-border bg-card p-4">
              <span className="font-display text-lg font-bold text-accent">{i + 1}</span>
              <span className="text-sm text-foreground">{s}</span>
            </li>
          ))}
        </ol>
      </Section>
    </>
  );
}
