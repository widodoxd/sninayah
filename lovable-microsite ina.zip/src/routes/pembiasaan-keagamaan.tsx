import { createFileRoute } from "@tanstack/react-router";

import { Badge, Card, PageHero, Section, Table } from "@/components/page-shell";

export const Route = createFileRoute("/pembiasaan-keagamaan")({
  head: () => ({
    meta: [
      { title: "Pembiasaan Keagamaan — SD Negeri Nganti 1" },
      { name: "description", content: "Program pembiasaan keagamaan harian, mingguan, dan tahunan di SD Negeri Nganti 1." },
      { property: "og:title", content: "Pembiasaan Keagamaan" },
      { property: "og:description", content: "Sholat dhuha, tahfidz, jumat berkah, dan kegiatan keagamaan lainnya." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 12"
        title="Pembiasaan Keagamaan"
        desc="Rangkaian pembiasaan yang menumbuhkan karakter religius siswa sejak pagi hingga pulang sekolah."
      />
      <Section title="Pembiasaan Harian">
        <Table
          head={["Waktu", "Kegiatan", "Sasaran", "Pendamping"]}
          rows={[
            ["06.50", "Salam dan salim di gerbang", "Semua siswa", "Guru piket"],
            ["07.00", "Tadarus dan doa bersama", "Semua kelas", "Wali kelas"],
            ["09.30", "Sholat dhuha berjamaah", "Kelas III-VI", "Guru PAI"],
            ["11.30", "Setoran hafalan surat pendek", "Kelas IV-VI", "Guru PAI"],
            ["12.30", "Sholat dzuhur berjamaah", "Kelas IV-VI", "Guru PAI & wali kelas"],
          ]}
        />
      </Section>
      <Section title="Pembiasaan Mingguan & Tahunan">
        <div className="grid gap-4 md:grid-cols-2">
          {[
            ["Jumat Berkah", "Mingguan", "Infak siswa dan berbagi makanan sehat kepada warga sekitar."],
            ["Kajian Keputrian", "Mingguan", "Materi adab dan kebersihan bagi siswa putri kelas V-VI."],
            ["Peringatan Maulid Nabi", "Tahunan", "Lomba keagamaan, ceramah, dan pentas hafalan siswa."],
            ["Pesantren Ramadhan", "Tahunan", "Kegiatan intensif ibadah dan akhlak selama Ramadhan."],
          ].map(([t, w, d]) => (
            <Card key={t}>
              <Badge tone="accent">{w}</Badge>
              <h3 className="mt-3 font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Kartu Kontrol Ibadah">
        <Card>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Setiap siswa kelas IV-VI memegang kartu kontrol ibadah yang ditandatangani orang tua dan
            diperiksa guru PAI setiap Senin. Kartu memuat catatan sholat lima waktu, mengaji, dan
            perilaku baik di rumah sebagai jembatan pembiasaan sekolah dan keluarga.
          </p>
        </Card>
      </Section>
    </>
  );
}
