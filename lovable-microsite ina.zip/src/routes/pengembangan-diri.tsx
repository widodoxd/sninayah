import { createFileRoute } from "@tanstack/react-router";

import { Badge, Card, PageHero, Section, Table } from "@/components/page-shell";

export const Route = createFileRoute("/pengembangan-diri")({
  head: () => ({
    meta: [
      { title: "Pengembangan Diri Guru PAI — SD Negeri Nganti 1" },
      { name: "description", content: "Riwayat diklat, seminar, KKG, dan komunitas belajar yang diikuti guru PAI SD Negeri Nganti 1." },
      { property: "og:title", content: "Pengembangan Diri Guru PAI" },
      { property: "og:description", content: "Diklat, seminar, KKG, dan komunitas belajar guru PAI." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Menu 9"
        title="Pengembangan Diri"
        desc="Peningkatan kompetensi guru melalui pelatihan, komunitas belajar, dan karya pengembangan profesi."
      />
      <Section title="Diklat & Seminar">
        <Table
          head={["Tahun", "Nama Kegiatan", "Penyelenggara", "Durasi"]}
          rows={[
            ["2023", "Diklat Implementasi Kurikulum Merdeka PAI", "Kemenag Kabupaten", "32 JP"],
            ["2023", "Workshop Penyusunan Modul Ajar", "KKG PAI Kecamatan", "16 JP"],
            ["2024", "Pelatihan Asesmen Berbasis Praktik", "Balai Diklat Keagamaan", "40 JP"],
            ["2025", "Bimtek Sekolah PAI Berkarakter", "Kemenag RI", "48 JP"],
            ["2026", "Pemanfaatan Media Digital untuk PAI", "Komunitas Belajar Daring", "20 JP"],
          ]}
        />
      </Section>
      <Section title="Komunitas Belajar">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ["KKG PAI Kecamatan", "Pertemuan bulanan penyusunan perangkat bersama"],
            ["Komunitas Belajar Sekolah", "Diskusi rutin hasil asesmen dan praktik baik"],
            ["Forum Guru PAI Daring", "Berbagi media dan bank soal antar sekolah"],
          ].map(([t, d]) => (
            <Card key={t}>
              <Badge>Aktif</Badge>
              <h3 className="mt-3 font-display text-base font-bold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </Card>
          ))}
        </div>
      </Section>
      <Section title="Karya Pengembangan Profesi">
        <ul className="space-y-3">
          {[
            "Best practice: Peningkatan hafalan surat pendek melalui metode talaqqi berpasangan.",
            "Penelitian tindakan kelas: Praktik sholat berbantuan video tutorial di kelas III.",
            "Media pembelajaran: Kartu tahfidz dan papan urutan gerakan sholat.",
          ].map((k) => (
            <li key={k} className="rounded-xl border border-border bg-card p-4 text-sm text-foreground">
              {k}
            </li>
          ))}
        </ul>
      </Section>
    </>
  );
}
