# Microsite Guru PAI — SD Negeri Nganti 1

Microsite personal guru PAI dengan 14 menu, dibangun sebagai website statis (belum perlu database). Semua isi awal memakai teks contoh yang mudah Anda ganti nanti.

## Struktur Menu (14 halaman)

1. Profil Sekolah — identitas, alamat, sejarah singkat, data pokok
2. Visi Misi — visi, misi, tujuan sekolah
3. Curriculum Vitae — biodata guru, pendidikan, riwayat mengajar, sertifikasi
4. Program Ajar — CP/TP, ATP, modul ajar per fase/kelas
5. Kegiatan KBM — dokumentasi & deskripsi kegiatan belajar
6. Asesmen Pembelajaran — jenis asesmen: formatif, sumatif, instrumen
7. Piloting Sekolah PAI Berkarakter — latar, program, capaian
8. Analisa Hasil Asesmen — tabel nilai ringkas + grafik sederhana per kelas
9. Pengembangan Diri — diklat, seminar, KKG, komunitas belajar
10. Data Siswa — tabel rekap siswa per kelas (dengan pencarian/filter)
11. Bank Soal — daftar soal per kelas/materi, bisa difilter
12. Pembiasaan Keagamaan — sholat dhuha, tahfidz, jumat berkah, dll
13. Galeri — grid foto kegiatan dengan lightbox
14. Berkas TPG — daftar dokumen TPG dengan status & tombol unduh

## Tampilan

- Nuansa islami-akademik: hijau tua/emerald + emas lembut, aksen motif geometris islami tipis, latar terang bersih
- Beranda: hero dengan foto/identitas guru, sambutan singkat, grid 14 menu berbentuk kartu ber-ikon
- Header dengan navigasi (menu dikelompokkan dalam dropdown agar 14 item rapi) + menu mobile
- Footer identitas sekolah, responsif penuh mobile/desktop

## Catatan Teknis

- TanStack Start file-based routing: satu file route per menu di `src/routes/` (mis. `profil-sekolah.tsx`), `src/routes/index.tsx` menjadi beranda
- Navigasi & footer bersama di `src/routes/__root.tsx`, komponen UI dipisah di `src/components/`
- Token warna/tipografi ditambahkan di `src/styles.css` (tanpa warna hardcode)
- Tiap halaman punya `head()` sendiri: title, description, og:title, og:description untuk SEO
- Data siswa / bank soal / berkas TPG memakai data contoh dalam file TypeScript, mudah diedit; bisa dipindah ke database (Lovable Cloud) di tahap berikutnya bila ingin bisa diubah dari halaman admin

## Tahap Berikutnya (opsional, tidak termasuk sekarang)

- Login admin + database agar konten, foto, dan data siswa bisa diperbarui tanpa coding
- Unggah berkas PDF nyata untuk Program Ajar dan Berkas TPG
